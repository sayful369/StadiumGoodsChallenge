package com.qa.test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;


import java.util.List;

import   static  io.restassured.RestAssured.*;



public class APITestChallenge {




    public static Response doGetRequest(String endpoint) {
        RestAssured.defaultParser = Parser.JSON;

        return
                given().headers("Content-Type", ContentType.JSON, "Accept", ContentType.JSON).
                        when().get(endpoint).
                        then().contentType(ContentType.JSON).extract().response();
    }

@Test
    public void pikachu1(){

    Response response = doGetRequest("https://pokeapi.co/api/v2/pokemon/pikachu/");

    List<String> jsonResponse = response.jsonPath().getList("abilities.ability.name");
    Assert.assertEquals(jsonResponse.get(0),"static");
    List<String> jsonResponse1 = response.jsonPath().getList("abilities.ability.url");
    Assert.assertEquals(jsonResponse1.get(0),"https://pokeapi.co/api/v2/ability/31/");

    List<String> jsonResponse2 = response.jsonPath().getList("abilities.is_hidden");
    Assert.assertEquals(jsonResponse2.get(0),true);

    List<String> jsonResponse3 = response.jsonPath().getList("abilities.slot");
    Assert.assertEquals(jsonResponse3.get(0),3);
}
    @Test
    public void pikachu2(){

        Response response = doGetRequest("https://pokeapi.co/api/v2/pokemon/pikachu/");

        List<String> jsonResponse = response.jsonPath().getList("abilities.ability.name");
        Assert.assertEquals(jsonResponse.get(1),"lightning-rod");
        List<String> jsonResponse1 = response.jsonPath().getList("abilities.ability.url");
        Assert.assertEquals(jsonResponse1.get(1),"https://pokeapi.co/api/v2/ability/9/");

        List<String> jsonResponse2 = response.jsonPath().getList("abilities.is_hidden");
        Assert.assertEquals(jsonResponse2.get(1),false);

        List<String> jsonResponse3 = response.jsonPath().getList("abilities.slot");
        Assert.assertEquals(jsonResponse3.get(1),1);
    }
    @Test
    public void snorlax1(){

        Response response = doGetRequest("https://pokeapi.co/api/v2/pokemon/snorlax/");

        List<String> jsonResponse = response.jsonPath().getList("abilities.ability.name");
        Assert.assertEquals(jsonResponse.get(0),"gluttony");
        List<String> jsonResponse1 = response.jsonPath().getList("abilities.ability.url");
        Assert.assertEquals(jsonResponse1.get(0),"https://pokeapi.co/api/v2/ability/82/");

        List<String> jsonResponse2 = response.jsonPath().getList("abilities.is_hidden");
        Assert.assertEquals(jsonResponse2.get(0),true);

        List<String> jsonResponse3 = response.jsonPath().getList("abilities.slot");
        Assert.assertEquals(jsonResponse3.get(0),1);
    }
    @Test
    public void snorlax2(){

        Response response = doGetRequest("https://pokeapi.co/api/v2/pokemon/snorlax/");

        List<String> jsonResponse = response.jsonPath().getList("abilities.ability.name");
        Assert.assertEquals(jsonResponse.get(1),"thick-fat");
        List<String> jsonResponse1 = response.jsonPath().getList("abilities.ability.url");
        Assert.assertEquals(jsonResponse1.get(1),"https://pokeapi.co/api/v2/ability/47/");

        List<String> jsonResponse2 = response.jsonPath().getList("abilities.is_hidden");
        Assert.assertEquals(jsonResponse2.get(1),false);

        List<String> jsonResponse3 = response.jsonPath().getList("abilities.slot");
        Assert.assertEquals(jsonResponse3.get(1),2);
    }
    @Test
    public void snorlax3(){

        Response response = doGetRequest("https://pokeapi.co/api/v2/pokemon/snorlax/");

        List<String> jsonResponse = response.jsonPath().getList("abilities.ability.name");
        Assert.assertEquals(jsonResponse.get(2),"immunity");
        List<String> jsonResponse1 = response.jsonPath().getList("abilities.ability.url");
        Assert.assertEquals(jsonResponse1.get(2),"https://pokeapi.co/api/v2/ability/17/");

        List<String> jsonResponse2 = response.jsonPath().getList("abilities.is_hidden");
        Assert.assertEquals(jsonResponse2.get(2),false);

        List<String> jsonResponse3 = response.jsonPath().getList("abilities.slot");
        Assert.assertEquals(jsonResponse3.get(2),3);
    }
    @Test
    public void charizard1(){

        Response response = doGetRequest("https://pokeapi.co/api/v2/pokemon/charizard/");

        List<String> jsonResponse = response.jsonPath().getList("abilities.ability.name");
        Assert.assertEquals(jsonResponse.get(0),"solar-power");
        List<String> jsonResponse1 = response.jsonPath().getList("abilities.ability.url");
        Assert.assertEquals(jsonResponse1.get(0),"https://pokeapi.co/api/v2/ability/94/");

        List<String> jsonResponse2 = response.jsonPath().getList("abilities.is_hidden");
        Assert.assertEquals(jsonResponse2.get(0),true);

        List<String> jsonResponse3 = response.jsonPath().getList("abilities.slot");
        Assert.assertEquals(jsonResponse3.get(0),3);
    }
    @Test
    public void charizard2(){

        Response response = doGetRequest("https://pokeapi.co/api/v2/pokemon/charizard/");

        List<String> jsonResponse = response.jsonPath().getList("abilities.ability.name");
        Assert.assertEquals(jsonResponse.get(0),"blaze");
        List<String> jsonResponse1 = response.jsonPath().getList("abilities.ability.url");
        Assert.assertEquals(jsonResponse1.get(0),"https://pokeapi.co/api/v2/ability/66/");

        List<String> jsonResponse2 = response.jsonPath().getList("abilities.is_hidden");
        Assert.assertEquals(jsonResponse2.get(0),false);

        List<String> jsonResponse3 = response.jsonPath().getList("abilities.slot");
        Assert.assertEquals(jsonResponse3.get(0),1);
    }




}


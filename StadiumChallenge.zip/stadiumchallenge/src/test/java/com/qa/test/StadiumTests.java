package com.qa.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qa.base.DriverFactory;
import com.qa.base.StadiumElements;

public class StadiumTests extends DriverFactory{
    StadiumElements stadiumElements = new StadiumElements();


 @Test
    public void logonTest() throws Exception {
    	Thread.sleep(5000);
    	
    	stadiumElements.getExcelData();
    	Thread.sleep(2000);
        stadiumElements.loginTest(1);
       Assert.assertEquals(stadiumElements.loginTest(1), true);

        stadiumElements.loginTest(2);
        Assert.assertEquals(stadiumElements.loginTest(2), true);


    }

@Test
public void Headerverification() throws Exception {
stadiumElements.headerverify();
Assert.assertEquals(stadiumElements.headerverify(), true);
    
}

@Test
public void sortLowtoHigh() throws InterruptedException {
	stadiumElements.clickSortButton();
}





}

package com.qa.base;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage extends DriverFactory {


	
	
    public void clickOn(By element){
        DriverFactory.getDriver().findElement(element).click();
    }

    public void setvalue(By element, String value){
        DriverFactory.getDriver().findElement(element).sendKeys(value);}

    public String getTextFromElement(By element){
        return DriverFactory.getDriver().findElement(element).getText();
    }

    public  WebElement InteractElement(By element) { 
    	return DriverFactory.getDriver().findElement(element);}


 


}

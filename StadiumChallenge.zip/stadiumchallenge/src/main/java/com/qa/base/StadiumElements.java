package com.qa.base;

import org.apache.poi.ss.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class StadiumElements extends DriverFactory {
    BasePage basePage = new BasePage();



    private By emailField = By.xpath("//input[@id='email']");
    private By passField = By.xpath("//input[@id='pass']");
    private By sendButton = By.xpath("//button[@id='send2']");
   private By modalPopup = By.xpath("//body[@class='cms-index-index cms-home us-store']/div[@class='wrapper']/div[@id='sg-subscribe']/div[@class='subscribe-modal-inner']/div[@class='subscribe-close-header']/a[@class='klaviyo_close_modal']/*[1]\")),20);\n");
    private By accountIcon = By.xpath("//a[@class='header-tools__link']//span[@class='header-tools__icon']");
    private By accoutnLink = By.xpath("");
    private By accountDashboardLink = By.xpath("//strong[contains(text(),'Account Dashboard')]");
    private By Nike = By.xpath("//div[@id='header-nav']//a[@class='level0 has-children'][contains(text(),'Nike')]");
    private By Jordan = By.xpath("//div[@id='header-nav']//a[@class='level0 has-children'][contains(text(),'Jordan')]");
    private By Adidas= By.xpath("//div[@id='header-nav']//a[@class='level0 has-children'][contains(text(),'Adidas')]");
    private By Yeezy = By.xpath("//div[@id='header-nav']//a[@class='level0 has-children'][contains(text(),'Yeezy')]");
    private By Shoes= By.xpath("//div[@id='header-nav']//a[@class='level0 has-children'][contains(text(),'Shoes')]");
    private By Women= By.xpath("//div[@id='header-nav']//a[@class='level0 has-children'][contains(text(),'Women')]");
    private By Streetwear= By.xpath("//div[@id='header-nav']//a[@class='level0 has-children'][contains(text(),'Streetwear')]");
    private By Trophycase= By.xpath("//div[@id='header-nav']//a[@class='level0 has-children'][contains(text(),'Trophy Case')]");
    private By Gifts= By.xpath("//a[@class='level0 has-children dyother dyMonitor']");
    private By Journal= By.xpath("//div[@id='header-nav']//a[@class='level0 has-children'][contains(text(),'Journal')]");
    private By homepage = By.xpath("//span[@class='logo-straight']");
    private By sort = By.xpath("//div[@id='sort_by_chosen']//a[@class='chosen-single']");
    private By LowtoHigh = By.xpath("//span[contains(text(),'Price Low to High')]");
    //methods


    public void enterEmail(String email) throws InterruptedException {
        basePage.setvalue(emailField, email);
        Thread.sleep(2000);
    }

    public void hoverClickAccoutn() throws InterruptedException {
        Actions actions = new Actions(getDriver());
        WebElement target = getDriver().findElement(accountIcon);
        actions.moveToElement(target).perform();
        Thread.sleep(2000);
        basePage.clickOn(accountIcon);

    }
    
    public void hoverHomePage() throws InterruptedException {
        Actions actions = new Actions(getDriver());
        WebElement target1 = getDriver().findElement(homepage);
        actions.moveToElement(target1).perform();
        Thread.sleep(2000);
        basePage.clickOn(homepage);

    }
    
    public void enterPass(String password) throws InterruptedException {
        basePage.setvalue(passField, password);
        Thread.sleep(2000);
    }

    public void clickSendButton() {
        basePage.clickOn(sendButton);
    }
    
  public void clickSortButton() throws InterruptedException {
	  basePage.clickOn(Yeezy);
	  Thread.sleep(2000);
	 basePage.clickOn(sort);
	  Actions actions = new Actions(getDriver());
      WebElement target2 = getDriver().findElement(LowtoHigh);
      actions.moveToElement(target2).perform();
      Thread.sleep(2000);
      basePage.clickOn(LowtoHigh);


  }

    
    public boolean verifyLoggedOn(){
        boolean check= false;
        try{
           check = getDriver().findElement(accountDashboardLink).isEnabled();
           check = true;
        }catch (Exception e){
            check = false;
        }
        return check;
    }
    public boolean verifyCategories(){
        boolean check= false;
        try{
           check = getDriver().findElement(Nike).isDisplayed();
         check = getDriver().findElement(Jordan).isDisplayed();
         check = getDriver().findElement(Adidas).isDisplayed();
        check = getDriver().findElement(Yeezy).isDisplayed();
           check = getDriver().findElement(Shoes).isDisplayed();
           //check = getDriver().findElement(Women).isDisplayed();
           check = getDriver().findElement(Streetwear).isDisplayed();
        // check = getDriver().findElement(Trophycase).isDisplayed();
         //  check = getDriver().findElement(Gifts).isDisplayed();
          // check = getDriver().findElement(Journal).isDisplayed();
           
           
           check = true;
        }catch (Exception e){
            check = false;
        }
        return check;
    }

    public List getExcelData() throws Exception {
        List<String> loginInfo = new ArrayList<String>();
        Workbook workbook = WorkbookFactory.create(new File("C:\\JavaCoding\\stadiumchallenge\\src\\main\\java\\com\\qa\\data\\Test Data QA Challenge 11.4.19 .xlsx"));
        Sheet sheet = workbook.getSheetAt(0);
        for (Row row : sheet) {
            for (Cell cell : row) {
                String cellValue = cell.getStringCellValue();
                System.out.print(cellValue + "\t");
                loginInfo.add(cellValue);
            }
            System.out.println();
        }
    for (String log :loginInfo){
        System.out.println(log);
    }

        return loginInfo;
    }

    //Test Methods

    public boolean loginTest(int i) throws Exception {

        List<String> data = getExcelData();

        //for (int i = 2; i < data.size(); i+=2) {
            hoverClickAccoutn();
            enterEmail(data.get(i+1));
            enterPass(data.get(i+2));
            clickSendButton();
            Thread.sleep(10000);

            
            return verifyLoggedOn();

        }
    public boolean verifySortlowtohigh(){
        boolean check= false;
        try{
           check = getDriver().findElement(LowtoHigh).isEnabled();
           check = true;
        }catch (Exception e){
            check = false;
        }
        return check;
    }

public boolean headerverify() throws InterruptedException {
	hoverHomePage();
	
	return verifyCategories();
	
}
public boolean verifysorting() throws InterruptedException {
	clickSortButton();
	
	
	return verifySortlowtohigh();
}

}

package com.qa.base;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;


public class DriverFactory {

        private static WebDriver driver = null;
        private static String startingURL = "https://stadium:goods2018!@stage.stadiumgoods.cloud";
        public static void clickOne(WebDriver driver,WebElement locator, int timeout) {
        	new WebDriverWait(driver,timeout).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(locator));
        	locator.click();
        	
        }
        	

        @BeforeClass
        public void beforeActions() throws InterruptedException {

            System.setProperty("webdriver.chrome.driver", "C:\\Users\\sisla\\Downloads\\chromedriver_win32 (3)/chromedriver.exe");
            driver = new ChromeDriver();
            driver.navigate().to(startingURL);
            Thread.sleep(5000);
            clickOne(driver,driver.findElement(By.xpath("//body[@class='cms-index-index cms-home us-store']/div[@class='wrapper']/div[@id='sg-subscribe']/div[@class='subscribe-modal-inner']/div[@class='subscribe-close-header']/a[@class='klaviyo_close_modal']/*[1]")),20);
            

        }

       @AfterClass
        public void tearDown() {
            driver.quit();
        }

        public static WebDriver getDriver() {
            return driver;
        }

    }

